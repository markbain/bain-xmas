
/*
===============================================
		
		FitVids  
	
===============================================
*/		

jQuery( document ).ready( function( $ ) { // Wrap all scripts in this
	
	$(document).ready(function(){
    $(".video-container").fitVids();
  });

}); // Wrap all scripts in this
