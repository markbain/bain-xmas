/*
=====================================================
		
		Wow.js
	
=====================================================
*/	

jQuery(document).ready(function($) { // Wrap all scripts in this
	new WOW().init();
});
